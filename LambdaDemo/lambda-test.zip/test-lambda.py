import json

def lambda_handler(event, context):
    # TODO implement
    print("hello, this is a lambda execution..")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello Lambda, From my code!')
    }
 